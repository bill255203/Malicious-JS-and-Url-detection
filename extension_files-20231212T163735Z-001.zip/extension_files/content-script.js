/*
	This file is the content script of the chrome extension.
	It will check every <script> tag of the website and send
	the code to "service-worker.js".
*/

const collection = document.getElementsByTagName("script");

// Get Javascript codes from src url and send to service worker
function getCode(url) {
	fetch(url)
    	.then(function (response) {
        	return response.text();
	    })
    	.then(function (myJS) {
        	console.log("Get Javascript code from", url);
	        code = myJS;
			chrome.runtime.sendMessage({
				message: "send_js_code",
				data: code,
				url: document.URL
			})
	    })
}

// Check every script tags and send to service worker
async function getJS() {
	for (let i = 0; i < collection.length; i++) {
		var code;
		console.log("No.", i);
		if (collection[i].innerHTML == '') {
			console.log("No innerHTML");
			await getCode(collection[i].src);
		} else {
			console.log(collection[i].innerHTML);
			await chrome.runtime.sendMessage({
				message: "send_js_code",
				data: collection[i].innerHTML,
				url: document.URL
			})
		}
	}
}

/*
	1. Check if current url is under google domain
	2. Check if current url is scanned by checking local storage
	3. Then get the Javascript code and send to service worker
*/
let tab = document.URL;
console.log(tab);
if (!tab.startsWith("https://www.google.com/")) {
	chrome.storage.local.get(tab, function (result) {
		if (result.num == undefined) {
			console.log("Not set yet");
			getJS();
		}
	});
}

