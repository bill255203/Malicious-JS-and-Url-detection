document.addEventListener("DOMContentLoaded", function() {
	const container = document.getElementById('container');
	const customInput = document.getElementById("other_url");
	const addButton = document.getElementById("addButton");

	// Load White list from local storage
	chrome.storage.local.get("benign", function(data) {
		console.log(data.benign);
		items = data.benign;
		for (let i = 0; i < items.length; i++) {
			var span = document.createElement('span');
			var button = document.createElement('button');
			const br = document.createElement('br');

			span.className = 'url';
			span.textContent = items[i];
			span.id = items[i];
			button.id = items[i];
			button.className = 'cross-button';
			button.innerHTML = '&#x2718;';
			button.addEventListener('click', (event) => {
				console.log("remove" + event.target.id);
				let index = items.indexOf(event.target.id);
				items.splice(index, 1);
				document.getElementById(event.target.id).remove();
				document.getElementById(event.target.id).remove();
			});
			container.appendChild(span);
			container.appendChild(button);
			container.appendChild(br);
		}
		
		// If white list is added
		addButton.addEventListener("click", () => {
			event.preventDefault();
			var span = document.createElement('span');
			var button = document.createElement('button');
			const br = document.createElement('br');

			span.className = 'url';
			span.id = customInput.value;
			span.textContent = customInput.value;
			button.id = customInput.value;
			button.className = 'cross-button';
			button.innerHTML = '&#x2718;';
			button.addEventListener('click', (event) => {
				console.log("remove" + event.target.id);
				let index = items.indexOf(event.target.id);
				items.splice(index, 1);
				document.getElementById(event.target.id).remove();
				document.getElementById(event.target.id).remove();
			});
			container.appendChild(span);
			container.appendChild(button);
			container.appendChild(br);
			items.push(customInput.value);
			alert("https://" + customInput.value);
		});

		document.getElementById('update').addEventListener('click', () => {
			chrome.storage.local.set({ ["benign"]: items }, () => {
				console.log("White list updated!")
			})
		})
	});
});


