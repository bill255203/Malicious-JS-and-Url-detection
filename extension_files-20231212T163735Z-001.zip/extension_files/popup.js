/*
	This file is the javascript file of "popup.html".
	It will query the url of current tab and tried to get
	the prediction result of the url.
*/

var url;
var white_list;
var server = true;

document.addEventListener("DOMContentLoaded", function() {
	document.getElementById("setting").addEventListener('click', () => {
		chrome.tabs.create({
			url: "onbroading.html"
		});
	});
});


chrome.storage.local.get("benign", (data) => {
	white_list = data.benign;

	chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
		url = tabs[0].url;
		let parsed_url = tabs[0].url.match(/[^\/]+/g);
		let domain = parsed_url[1];
		let container = document.getElementById('container');
	
		/* The url is in white list */
		if (white_list.includes(domain)) {
			let span = document.createElement('span');
			let icon = document.createElement('i');
			span.textContent = "This url is marked in white list.";
			icon.className = 'fa fa-check-circle-o';
			icon.style.fontSize = '24px';
			span.appendChild(icon);
			container.appendChild(span);
		} else {
			getResult(url, function (result) {
				let state = document.createElement('p');
				let good = document.createElement('i');
				let bad = document.createElement('i');
				let running = document.createElement('i');

				good.className = 'fa fa-smile-o';
				good.style.fontSize = '24px';
				bad.className = 'fa fa-frown-o';
				bad.style.fontSize = '24px';
				running.className = 'fa fa-spinner';
				running.style.fontSize = '24px';

				if (result === undefined) {
					console.log("prediction not complete");
					state.innerHTML = "Analysing...  ";
					state.appendChild(running);
					container.appendChild(state);
				} else {
					console.log("prediction completed");

					state.innerHTML = "Analysis complete  ";
					if (result.benign === result.num && !result.isPhish) {
						console.log("good website");

						state.appendChild(good);
						container.appendChild(state);
					} else {
						console.log("malicious website");

						state.appendChild(bad);
						container.appendChild(state);
					}
					let button = document.createElement('button');
					button.innerHTML = "view report";
					container.appendChild(button);
					button.addEventListener('click', () => {
						let analysis_url = document.createElement('p');
						let num_script = document.createElement('p');
						let num_malicious = document.createElement('p');
						let phishing = document.createElement('p');
					
						analysis_url.innerHTML = "URL: " + url;
						num_script.innerHTML = "Number of script: " + result.num;
						num_malicious.innerHTML = "Number of malicious script: " + (result.num - result.benign);
						phishing.innerHTML = result.isPhish ? "Phishing detected" : "No Phishing detected";
						container.appendChild(analysis_url);
						container.appendChild(num_script);
						container.appendChild(num_malicious);
						container.appendChild(phishing);
					});
				}
			});
		}
	});
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.message === "server_error") {
		if (server == true) {
			let container = document.getElementById('container');
			let error = document.createElement('p');
			let error_icon = document.createElement('i');
			error.innerHTML = "[*]Server is not available";
			error.id = "error";
			error_icon.className = "fa fa-exclamation-circle";
			error_icon.style.fontSize = "24px";
			error_icon.id = "error_icon";
			container.appendChild(error_icon);
			container.appendChild(error);
			server = false;
		}
	}
	if (request.message === "server_on") {
		if (server == false) {
			document.getElementById('error').remove();
			document.getElementById('error_icon').remove();
			server = true;
		}
	}
});

////* Function for getting local storage data *////
function getResult(url, callback) {
	chrome.storage.local.get(url, function (result) {
		if (chrome.runtime.lastError) {
			console.error("Error retrieving data: " + chrome.runtime.lastError);
		} else {
			callback(result[url]);
		}
	});
}

