/*
	This file is the background script of the chrome extension.
	When it get script file from content script, it will communicate
	with the server and store the prediction result in local storage.
*/

importScripts("esprima.js")

///* When the extension is installed set default white list & open the setting page *///
chrome.runtime.onInstalled.addListener(({reason}) => {
	//if (reason === "install") {
	var list = ["www.google.com", "www.youtube.com"];
	chrome.storage.local.set({ ["benign"]: list }, () => {
		console.log("Default white list url is set.");
	});
	chrome.tabs.create({
		url: "onbroading.html"
	});
	//}
});

////* Variable declaration *////
var output;			// output of esprima
var get_code;		// JS code get from content script
var url;			// url of current website
var dict = {};		// {url: list of AST}
var phish_dict = {};// {url: phishing or not}
var tmp = [];
var sent = {};		// {url: number of script be sent}
var received = {};	// {url: number of prediction been received}
var benign = {};	// {url: number of benign script}
var white_list;

////* Send Javascript AST to the server *////
function sendAST(url, code) {
	console.log("Send script of website: " + url);
	fetch('http://127.0.0.1:5000/process', {
		method: 'POST',
		mode: 'cors',
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({ "data": code }),
	})
	.then((response) => response.json())
	.then((result) => {
		received[url] += 1;
		console.log("Received url: " + received[url]);
		if (result.message == 'benign website') {
			console.log("benign script");
			benign[url] += 1;
			if (received[url] == dict[url].length) {
				setResult(url, dict[url].length, benign[url], phish_dict[url]);
			}
		} else {
			console.log("malicious script");
			if (received[url] == dict[url].length) {
				setResult(url, dict[url].length, benign[url], phish_dict[url]);
			}
		}
		chrome.runtime.sendMessage({
			message: "server_on",
		});
	})
	.catch((error) => {
		console.error('Error while communicating with server');
		chrome.runtime.sendMessage({
			message: "server_error",
		});
	})
}

////* Send URL to the server *////
function sendURL(url) {
	fetch('http://127.0.0.1:5000/url_test', {
		method: 'POST',
		mode: 'cors',	
		headers: {
			'Content-Type': 'application/json',
		},
		body: JSON.stringify({ "data": url }),
	})
	.then((response) => response.json())
	.then((result) => {
		if (result.message == 'Phishing Alert') {
			console.log("Phishing Alert");
			phish_dict[url] = true;
		} else {
			console.log("No Phishing");
		}
	})
	.catch((error) => {
		console.error('Error while communicating with server');
	})
}

////* Listen for content script to get Javascript code *////
chrome.storage.local.get("benign", (data) => {
	white_list = data.benign;
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.message == "send_js_code") {
		console.log("Get JS code from content-script");

		/* Parse the url and compare with white list */
		let parsed_url = request.url.match(/[^\/]+/g);
		let domain = parsed_url[1];
		console.log(domain);

		/* If the domain is not in white list => start detecting */
		if (!white_list.includes(domain)) {
			console.log("Domain not in white list. Start detecting...");

			get_code = request.data;
			url = request.url;
			output = esprima.parseScript(get_code);
			if (url in dict) {
				dict[url].push(output);
			} else {
				tmp = [];
				tmp.push(output);
				dict[url] = tmp;
				sent[url] = 0;
				benign[url] = 0;
				received[url] = 0;
				phish_dict[url] = false;
			}
			console.log(dict[url].length);
			setTimeout(() => getAndSend(url), 3000);
		} else {
			console.log("Domain in white list. (This means you trust this website, you can change your white-list from setting.)");
		}
	}
})

////* Set the prediction result of certain url in local storage *////
function setResult(url, total, good, phishing) {
	let value = {
		num: total,
		benign: good,
		isPhish: phishing
	};
	console.log('Num of scripts: ' + total);
	console.log('Num of benign scripts: ' + good);
	if (phishing) {
		console.log('Phishing website: yes');
	} else {
		console.log('Phishing website: no');
	}
	chrome.storage.local.set({ [url]: value }, () => {
		console.log('Set url info: ' + url);
	});
}

////* Check if there are unsent AST and call sendAST function *////
async function getAndSend(url) {
	while (sent[url] < dict[url].length) {
		// Send url to the server first
		if (sent[url] == 0) {
			sendURL(url);
		}
		// Send each AST to the server
		await sendAST(url, dict[url][sent[url]]);
		sent[url] += 1;
		//if (sent >= 50) {
		//	codes.splice(0, 50);
		//	sent -= 50;
		//	count -= 50;
		//}
	}
}


//////////////// Unused code //////////////////

/*
chrome.tabs.onActivated.addListener(function (tabId, windowId) {
	console.log("onActivated");
	console.log(tabId);
	if (tabId in tab2url) {
		updating(tab2url[tabId], dict[tab2url[tabId]].length, benign[tab2url[tabId]]);
	}
})
*/

////* Update the information of url in popup.js *////
/*
function updating(url, count, benign) {
	chrome.runtime.sendMessage({
		msg: "update_result",
		data: {
			"url": url,
			"script": count,
			"benign": benign,
			"malicious": (count - benign)
		}
	})
}
*/
